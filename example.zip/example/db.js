module.exports = function() {
  return {
    profiles: require('./profiles.json'),
    tweets: require('./tweets.json'),
    hashtag_cats_are_evil: require('./hashtag_cats_are_evil.json'),
    hashtag_hangry: require('./hashtag_hangry.json')
  }
}